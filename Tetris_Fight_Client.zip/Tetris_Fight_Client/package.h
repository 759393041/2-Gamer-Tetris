#ifndef PACKAGE_H
#define PACKAGE_H
#include"cell.h"

class BoardTrasInfo
{
public:
    int mark;
    std::vector<cell> opponents_colorful_cell;
};


#endif // PACKAGE_H
