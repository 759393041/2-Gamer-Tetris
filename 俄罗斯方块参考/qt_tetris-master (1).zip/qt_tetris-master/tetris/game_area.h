#ifndef GAME_AREA_H
#define GAME_AREA_H

#include <QWidget>
#include <QPaintEvent>
#include <QTimer>
#include <QTime>
#include <QPainter>
#include <QMessageBox>
#include "blocks.h"

class Game_Area : public QWidget
{
    Q_OBJECT
public:
    explicit Game_Area(QWidget *parent = nullptr);
    void New_Game();
    int set_timer_interval(int score);
    void mytimer_update_blocks();
    void draw_fixedBlocks();
    void draw_droppingBlocks();
    void draw_frame();
    bool isContinue();
    void keypressed(int key);
    bool hitTop();
    void rowFull();
    void deleteRow(int col);
    bool hitFixblocks();
    bool hitBottom();
    bool hitSides();
    void change_mShape(int add);
    QColor setColor();
    QMessageBox *mybox;


protected:
    void paintEvent(QPaintEvent *event);


private:
    int Gamescore=0;
    QTimer *mytimer;
    int Timer_interval=0;
    int Gamelevel=0;
    blocks CurmovingBlocks;
    blocks FixedBlocks;
    blocks NextBlocks;
    blocks FrameBlocks;
    QColor CurmovingBlocks_color;
    QColor NextBlocks_color;
















signals:
    void NextBlocks_change(BLOCKS_TYPE block_type, int block_direction,QColor next_color);
    void Gamescore_change(int score);
    void Gamelevel_change(int level);

public slots:
};

#endif // GAME_AREA_H
