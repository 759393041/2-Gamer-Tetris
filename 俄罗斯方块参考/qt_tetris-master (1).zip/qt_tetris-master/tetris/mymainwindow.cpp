#include "mymainwindow.h"
#include "ui_mymainwindow.h"
#include <QDir>
#include <QDebug>



myMainWindow::myMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::myMainWindow)
{


    setFixedSize(905,750);
    ui->setupUi(this);
    setWindowTitle("程序媛讲QT-俄罗斯方块");
    setStyleSheet("border-image: url(:/new/prefix1/image/backimage.png);");
    QPixmap pixmap;//定义QPixmap对象
    pixmap.load(":/new/prefix1/image/title.png");//加载图片
    ui->image_label->setPixmap(pixmap);

    connect(ui->game_widget, &Game_Area::NextBlocks_change,ui->nextShap_widget , &Nextblock_Area::NextBlocks_deal);
    connect(ui->game_widget, &Game_Area::Gamescore_change,this , &myMainWindow::Gamescore_deal);
    connect(ui->game_widget, &Game_Area::Gamelevel_change,this , &myMainWindow::Gameslevel_deal);
    connect(ui->help_action, &QAction::triggered,[=]()
    {
        QMessageBox mybox;
        mybox.about(this,"HELP!","操作方式：\n          上键：变换方向\n          Ctrl键：移到底部\n          左右下键：移动一格");
    });

    ui->game_widget->New_Game();

}



void myMainWindow::Gamescore_deal(int score)
{
    ui->score_label->setText(QString::number(score));
}


void myMainWindow::Gameslevel_deal(int level)
{
    ui->passnum_label->setText(QString::number(level));
}


myMainWindow::~myMainWindow()
{
    delete ui;
}



void myMainWindow::keyPressEvent(QKeyEvent *event)
{
    ui->game_widget->keypressed(event->key());
}
