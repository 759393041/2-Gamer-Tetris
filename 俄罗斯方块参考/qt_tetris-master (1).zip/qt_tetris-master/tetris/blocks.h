#ifndef BLOCKS_H
#define BLOCKS_H

#include <QWidget>
#include <QDebug>
#include <QVector>
#include <QPoint>
#include <QPainter>

enum BLOCKS_TYPE{
    BLOCK_1 = 0,		//长条
    BLOCK_2,			//山字形
    BLOCK_3,			//手枪形1
    BLOCK_4,			//手枪形2
    BLOCK_5,			//田
    BLOCK_6,			//Z字形1
    BLOCK_7,			//Z字形2
    BLOCK_MAX,
};



class blocks : public QWidget
{
    Q_OBJECT
public:
    explicit blocks(QWidget *parent = nullptr);
    void draw_block(BLOCKS_TYPE block_type, int block_direction);
    void draw(QPainter& painter);
    void InitNew(int seed);
    void move(int x,int y);


public:
    QVector<QPoint> pointArray;
    QPoint mPos;
    BLOCKS_TYPE mType;
    int mShape;

private:


signals:

public slots:
};

#endif // BLOCKS_H
