#ifndef MYMAINWINDOW_H
#define MYMAINWINDOW_H

#include <QMainWindow>


namespace Ui {
class myMainWindow;
}

class myMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit myMainWindow(QWidget *parent = 0);
    void Gamescore_deal(int score);
    void Gameslevel_deal(int level);
    ~myMainWindow();

private:
    Ui::myMainWindow *ui;


protected:
    void keyPressEvent(QKeyEvent *event);


};

#endif // MYMAINWINDOW_H
