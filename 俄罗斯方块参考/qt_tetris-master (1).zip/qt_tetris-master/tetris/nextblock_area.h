#ifndef NEXTBLOCK_AREA_H
#define NEXTBLOCK_AREA_H

#include <QWidget>
#include "blocks.h"

class Nextblock_Area : public QWidget
{
    Q_OBJECT
public:
    explicit Nextblock_Area(QWidget *parent = nullptr);
    void NextBlocks_deal(BLOCKS_TYPE block_type, int block_direction,QColor next_color);



protected:
    void paintEvent(QPaintEvent *event);

signals:

private:
    blocks mBlock;
    QColor Block_color;
public slots:
};

#endif // NEXTBLOCK_AREA_H
