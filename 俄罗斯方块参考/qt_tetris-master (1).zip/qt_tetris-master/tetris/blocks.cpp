#include "blocks.h"




#define block_width 35


blocks::blocks(QWidget *parent) : QWidget(parent)
{
     mPos = QPoint(0,0);
}



void blocks::draw(QPainter& painter)
{
    for(int i=0;i<pointArray.count();i++)
    {
        QPoint point = pointArray[i];
        painter.drawRect(point.x()*block_width, point.y()*block_width, block_width, block_width);
    }

}





void blocks::move(int x,int y)
{
    for (int i = 0; i<pointArray.size(); i++)
    {
        int x1 = pointArray[i].x() + x;
        int y1 = pointArray[i].y() + y;
        pointArray[i].setX(x1);
        pointArray[i].setY(y1);
    }
    mPos = mPos +QPoint(x,y);
}





void blocks::InitNew(int seed)
{
       mPos = QPoint(0,0);
       qsrand(seed);
       BLOCKS_TYPE type=(BLOCKS_TYPE)(qrand()%BLOCK_MAX);
       int direction=qrand()%4;
       draw_block(type,direction);
}







void blocks::draw_block(BLOCKS_TYPE block_type, int block_direction)
{
    pointArray.clear();
    mType = block_type;
    mShape = block_direction;

    switch(block_type)
    {
        case BLOCK_1:	                //长条
                if(block_direction%2==0)
                {
                      pointArray<<mPos+QPoint(0,0);
                      pointArray<<mPos+QPoint(0,1);
                      pointArray<<mPos+QPoint(0,2);
                      pointArray<<mPos+QPoint(0,3);

                }
                if(block_direction%2==1)
                {
                      pointArray<<mPos+QPoint(0,0);
                      pointArray<<mPos+QPoint(1,0);
                      pointArray<<mPos+QPoint(2,0);
                      pointArray<<mPos+QPoint(3,0);
                }
                break;
        case BLOCK_2:					//山字形
                if(block_direction==0)
                {
                     pointArray<<mPos+QPoint(1,0);
                     pointArray<<mPos+QPoint(0,1);
                     pointArray<<mPos+QPoint(1,1);
                     pointArray<<mPos+QPoint(2,1);
                }
                if(block_direction==1)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(0,2);
                    pointArray<<mPos+QPoint(1,1);

                }
                if(block_direction==2)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(2,0);
                    pointArray<<mPos+QPoint(1,1);

                }
                if(block_direction==3)
                {
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(1,2);
                }
                break;
        case BLOCK_3:				    //手枪形1
                if(block_direction==0)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(2,0);
                    pointArray<<mPos+QPoint(2,1);
                }
                if(block_direction==1)
                {
                    pointArray<<mPos+QPoint(0,2);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(1,2);
                }
                if(block_direction==2)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(2,1);
                }
                if(block_direction==3)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(0,2);
                }
                break;
        case BLOCK_4:				   //手枪形2
                if(block_direction==0)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(2,0);
                    pointArray<<mPos+QPoint(0,1);
                }
                if(block_direction==1)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(1,2);
                }
                if(block_direction==2)
                {
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(2,1);
                    pointArray<<mPos+QPoint(2,0);
                }
                if(block_direction==3)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(0,2);
                    pointArray<<mPos+QPoint(1,2);
                }
                break;

        case BLOCK_5:
                pointArray<<mPos+QPoint(0,0);
                pointArray<<mPos+QPoint(0,1);
                pointArray<<mPos+QPoint(1,0);
                pointArray<<mPos+QPoint(1,1);
                break;		//田

        case BLOCK_6:				//Z字形1
       {
                if(block_direction%2==0)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(2,1);
                }
                if(block_direction%2==1)
                {
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(0,2);
                }
                break;
        }
        case BLOCK_7:				//Z字形2
        {
                if(block_direction%2==0)
                {
                    pointArray<<mPos+QPoint(1,0);
                    pointArray<<mPos+QPoint(2,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(1,1);
                }
                if(block_direction%2==1)
                {
                    pointArray<<mPos+QPoint(0,0);
                    pointArray<<mPos+QPoint(0,1);
                    pointArray<<mPos+QPoint(1,1);
                    pointArray<<mPos+QPoint(1,2);
                }
                break;
         }

       default:
            break;
    }
}
