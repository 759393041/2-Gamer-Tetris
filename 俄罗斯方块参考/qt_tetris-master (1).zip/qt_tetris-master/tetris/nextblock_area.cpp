#include "nextblock_area.h"



#define block_width 28
#define init_x 25
#define init_y 22

Nextblock_Area::Nextblock_Area(QWidget *parent) : QWidget(parent)
{

}




void Nextblock_Area::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(Block_color);
    painter.setPen(QPen(QColor(Qt::black),1));

    foreach (QPoint pt, mBlock.pointArray)
    {
        int x = init_x + pt.x() * block_width;
        int y = init_y + pt.y() * block_width;
        painter.drawRect(x, y, block_width, block_width);
    }

    update();

}



void Nextblock_Area::NextBlocks_deal(BLOCKS_TYPE block_type, int block_direction,QColor next_color)
{
    mBlock.draw_block(block_type,block_direction);
    Block_color=next_color;

}


