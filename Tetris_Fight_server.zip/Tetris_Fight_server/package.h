#ifndef PACKAGE_H
#define PACKAGE_H
#include"cell.h"
class BoardTrasInfo
{
public:
    int mark;
    cell opponents_colorful_cell;
};

#endif // PACKAGE_H
